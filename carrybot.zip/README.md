
Welcome to the Carrybot
=========================
This is a small bot dedicated to Carryminati.

About Project
------------
This bot does small stuff which will be required for discord servers.

Made by [Rajeev K Rao](https://about.me/rajeevkrao)
---------------------------------------------------