module.exports = (client) => {
client.channels.cache.get("501470146167177238").setName("Handling " + client.guilds.cache.size + " Servers");
  
};