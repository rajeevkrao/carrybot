//direct messages
const fs = require("fs");

const https = require('https');

//const youtube = require("./modules/youtube.js");

const { RichEmbed } = require('discord.js');

const config = require("../config.json");
const dscmds = require("../DSCMDS.js");

const usrcmds = require("../users.js");
const guildscmds = require("./botcommands.js");
const msglog = require("./msglogger.js");

var express = require('express');
var app = express();
/*
var gsetfile = "../guilds.json";
const gset = require(gsetfile);
const gsetsync = fs.readFileSync(gsetfile);
*/

module.export = (message, client) => {



};